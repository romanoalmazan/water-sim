// TypeScript interfaces for pipe data structure
export interface PipeSegment {
  SegmentID: number
  Water: number
  Light: number
}

